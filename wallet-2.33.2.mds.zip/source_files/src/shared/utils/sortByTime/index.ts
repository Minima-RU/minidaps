export const sortByTime = (a: string, b: string) => {
    return a.localeCompare(b);
};

export default sortByTime;
