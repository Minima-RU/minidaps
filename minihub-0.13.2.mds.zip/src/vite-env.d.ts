/// <reference types="vite/client" />

declare const Android: any;
declare const MDS: any;
