export const mask = {
  passwordMaskOptions: { maskWith: "*", maxMaskedCharacters: 24, unmaskedStartCharacters: 0, unmaskedEndCharacters: 0 },
  passwordFields: ['password','seed','privatekey','confirm','phrase'],
};
