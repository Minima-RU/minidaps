export const IS_MINIMA_BROWSER = (window as any).navigator.userAgent.includes('Minima Browser');
