declare module '*.module.css'
declare module '*.svg'
declare module '*.png'
