export type MinimaFile = {
  name: string;
  size: number;
  location: string;
}
