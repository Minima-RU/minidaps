export const isMinimaBrowser = (window as any).navigator.userAgent.includes('Minima Browser');
