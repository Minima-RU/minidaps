(window as any).__NODE_PASSWORD__ = false;
