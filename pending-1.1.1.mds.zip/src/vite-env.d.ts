/// <reference types="vite/client" />
declare var __NODE_PASSWORD__: any;
