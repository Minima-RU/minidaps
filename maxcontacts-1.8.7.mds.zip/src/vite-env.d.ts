/// <reference types="vite/client" />

declare const MDS: any;
declare const Android: any;
